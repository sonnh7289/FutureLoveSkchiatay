import { useState } from "react";

function Menu() {


    return (
        <div>
            <div className="slab text-5xl">
                <div className="">
                    <ul>
                        <li>
                            First meet
                        </li>
                        <li>
                            History

                        </li>
                    </ul>
                </div>
            </div>
        </div>
    );
}

export default Menu;