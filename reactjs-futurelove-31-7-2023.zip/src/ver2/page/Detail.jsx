
import FirstMeet from './app/FirstMeet'
function Detail() {
    return (
        <div>
            <FirstMeet />
        </div>
    );
}

export default Detail;