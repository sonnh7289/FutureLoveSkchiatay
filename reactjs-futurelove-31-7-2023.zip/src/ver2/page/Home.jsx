import React from "react";
import { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import Header from "../components/Header";
import boy from "../components/image/nam.png";
import boyM from "../components/image/Component131.png";
import girlM from "../components/image/Component130.png";
import uilPlus from "../components/image/uil_plus.png";
import girl from "../components/image/nu.png";
import heart from "../components/image/heart.png";
import imgBg from "../components/image/backgroundLove.jpg";
import { BsFillHeartFill } from "react-icons/bs";
import ReactLoading from "react-loading";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { getFullFaceDescription, createMatcher, loadModels } from '../../api/face';
import Clock from "../components/clock";

const JSON_PROFILE = require('../../descriptors/bnk48.json');
function Home() {
  const Api_key = "938c8d9c19d7ec0c6f5225d69a3ef3ae";
  const server = "http://14.225.7.221:9090/getdata";
  const [showModal, setShowModal] = React.useState(false);
  const [data, setData] = useState([]);
  const [nam1, setBoy] = useState(boy);
  const [nu1, setNu] = useState(girl);
  const [nam2, setBoy2] = useState(boyM);
  const [nu2, setNu2] = useState(girlM);
  const [uil, setUil] = useState(uilPlus);
  const [bsHeart, setHeart] = useState(heart);
  const [image1, setImage1] = useState(null);
  const [image2, setImage2] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isFilePicked, setIsFilePicked] = useState(false);
  const [link, setLink] = useState(null);
  const navigate = useNavigate();
  const [faceMatcher, setFaceMatcher] = useState(null);
  const [dataImg, setDataImg] = useState(null);
  //
  useEffect(() => {
    const initialize = async () => {
      await loadModels();
      setFaceMatcher(await createMatcher(JSON_PROFILE));
    };

    initialize();
  }, []);
  //
  const uploadImage = async (image, setImage) => {
    const formData = new FormData();
    formData.append("image", image);
    try {
      if (image) {
        const input = document.getElementById(
          setImage === setImage1 ? "male" : "female"
        );
        if (input) {
          input.style.display = "none";
        }
        const apiResponse = await axios.post(
          `https://api.imgbb.com/1/upload?key=${Api_key}`,
          formData
        );
        setImage(apiResponse.data.data.url);
        let apiImage = apiResponse.data.data.url;

        await getFullFaceDescription(apiImage).then(fullDesc => {
          if (fullDesc.length == 0) {
            setShowModal(true)
          }
          else {
            setImage(apiImage);
          }
        });
      }
    } catch (error) {
      throw error;
    }
  };

  const closeUploadImg = async () => {
    setImage1(null)
    setImage2(null)
    setShowModal(false)
  }

  const handleChangeImage = async (event, setImage) => {
    event.preventDefault();
    let file = event.target.files[0];
    if (file) {
      setImage(file);
    }
  };

  const fetchData = async () => {
    setIsLoading(true);
    try {
      await uploadImage(image1, setImage1);
      await uploadImage(image2, setImage2);
      const response = await axios.post(
        `${server}`,
        {},
        {
          headers: {
            Link_img1: image1,
            Link_img2: image2,
          },
        }
      );


      setData(response.data);
      console.log(response.data);
      setLink(response.data.id);
      setIsLoading(false);
      toast.success("Upload và lưu dữ liệu thành công");
      navigate("/" + response.data.json2[0].id_toan_bo_su_kien);
    } catch (error) {
      setIsLoading(false);
      throw error;
    }
  };

  useEffect(() => {
    uploadImage(image1, setImage1);
    uploadImage(image2, setImage2);
    console.log("useEffect");
  }, [image1, image2]);

  const renderLoading = () => {
    if (isLoading) {
      return (
        <div
          style={{
            display: "flex",
            justifyContent: "right",
            alignItems: "center",
          }}
        >
          <ReactLoading type={"bars"} color={"#C0C0C0"} />
        </div>
      );
    }
    return null;
  };

  return (
    <div style={{ backgroundImage: `url(${imgBg})` }} className="bg-no-repeat bg-cover">
      <Header />
      <div className="flex justify-center mt- mb-24">
        <Clock className="" />
      </div>
      <div className="lg:block hidden">
        <div className="flex justify-between lg:mx-52 pb-32">
          <div>
            <div style={{ backgroundImage: `url(${nam1})`, height: `411px`, width: `410px` }} alt="" className="responsiveImg">
              <div className="responsiveImg absolute cursor-pointer w-[331px] h-[331px] rounded-[50%] mt-110 ml-6 bg-center bg-no-repeat bg-cover" style={image1 ? { backgroundImage: `url(${image1})` } : null}></div>
              <input
                onChange={(e) => handleChangeImage(e, setImage1)}
                style={image1 ? { backgroundImage: `url(${image1})` } : null}
                type="file"
                className={image1 ? " opacity-0 responsiveImg cursor-pointer w-[331px] h-[331px] rounded-[50%] mt-110 ml-6 bg-center bg-no-repeat bg-cover" : " opacity-0 cursor-pointer w-[331px] h-[331px] rounded-[50%] absolute mt-110 ml-6 bg-center bg-no-repeat bg-black"}
              />
            </div>
            <div className="text-center lg:mt-16 text-3xl slab text-[#7A1E3E] font-semibold">Your Name Here!</div>
          </div>

          <div className="flex justify-center items-center transition-transform duration-300 hover:scale-125 mx-auto">
            <img src={bsHeart} alt="" className="cursor-pointer lg:w-48 lg:h-44 bg-center bg-no-repeat" />
          </div>


          {/*  */}
          {/* <div className="flex justify-center items-center transition-transform duration-300 hover:scale-125 ">
          <BsFillHeartFill className="w-48 h-48 text-[#FF9F9F] " />
          <span
            onClick={fetchData}
            className="text-4xl font-bold mt-14 absolute text-[#7A1E3E]"
          >
            Bắt đầu
          </span>
        </div> */}

          {/*  */}
          <div className="">
            <div style={{ backgroundImage: `url(${nu1})`, height: `419px`, width: `407px` }} alt="" className="">
              <div className="responsiveImg absolute cursor-pointer w-[331px] h-[331px] rounded-[50%] mt-4 ml-24 bg-center bg-no-repeat bg-cover" style={image2 ? { backgroundImage: `url(${image2})` } : null}></div>
              <input
                onChange={(e) => handleChangeImage(e, setImage2)}
                style={image2 ? { backgroundImage: `url(${image2})` } : { backgroundImage: `url(${uil})` }}
                type="file"
                className={image2 ? " opacity-0 cursor-pointer w-[331px] h-[331px] rounded-[50%] absolute mt-4 ml-24 bg-center bg-no-repeat bg-cover" : "opacity-0 cursor-pointer w-[331px] h-[331px] rounded-[50%] ml-24 mt-4 absolute bg-center bg-no-repeat"}
              />
            </div>

            <div className="text-center lg:mt-16 text-3xl slab text-[#7A1E3E] font-semibold">Her Name Here!</div>
          </div>
        </div>
      </div>
      {/* <div className="flex flex-row h-4/5  justify-evenly content-center items-center relative top-32">
        <div className="flex flex-col items-center  relative">
          <img src={boy} alt="" className="w-500 h-500 static" />
          <input
            onChange={(e) => handleChangeImage(e, setImage1)}
            style={{ backgroundImage: `url(${image1})` }}
            type="file"
            className="w-[360px] h-[360px]  rounded-[50%] absolute bottom-8 left-8 z-10 bg-center bg-no-repeat bg-cover bg-[#FFDAB9]"
          />

        </div>

        <div className="flex flex-col items-center transition-transform duration-300 hover:scale-125 ">
          <BsFillHeartFill className="w-48 h-48 text-[#FF9F9F] " />
          <span
            onClick={fetchData}
            className="text-4xl font-bold mt-14 absolute text-[#7A1E3E]"
          >
            Bắt đầu
          </span>
        </div>
        <div className="flex flex-col items-center  relative">
          <img src={girl} alt="" className="w-500 h-500 static" />
          <input
            onChange={(e) => handleChangeImage(e, setImage2)}
            style={{ backgroundImage: `url(${image2})` }}
            type="file"
            className="w-[360px] h-[360px]  rounded-[50%] absolute top-8 right-8  z-10 bg-center bg-no-repeat bg-cover bg-[#FFDAB9] "
          />
        </div>
      </div> */}



      <div className="flex justify-between mx-9 pb-32 lg:hidden">
        <div className="">
          <div style={{ backgroundImage: `url(${nam2})`, height: `120px`, width: `120px` }} alt="" className="responsiveImg">
            <div className="responsiveImg absolute mt-8 ml-2 cursor-pointer w-[95px] h-[97.5px] rounded-[50%] bg-center bg-no-repeat bg-cover" style={image1 ? { backgroundImage: `url(${image1})` } : null}>
              <input
                onChange={(e) => handleChangeImage(e, setImage1)}
                style={image1 ? { backgroundImage: `url(${image1})` } : null}
                type="file"
                className={image1 ? "opacity-0 responsiveImg cursor-pointer w-[97px] h-[95.5px] rounded-[50%] bg-center bg-no-repeat bg-cover" : "opacity-0 bg-black cursor-pointer w-[97px] h-[95.5px] rounded-[50%] absolute mt-love3 ml-love3 bg-center bg-no-repeat"}
              />
            </div>

          </div>
          <div className="text-center mb-64 lg:text-3xl text-2xl mt-4 slab">Your Name Here!</div>
        </div>

        <div className="flex justify-center -mt-56 items-center transition-transform duration-300 hover:scale-125 mx-auto">
          <img src={bsHeart} alt="" className="cursor-pointer w-24 h-20 bg-center bg-no-repeat" />
        </div>

        <div className="">
          <div style={{ backgroundImage: `url(${nu2})`, height: `120px`, width: `116px` }} alt="" className="responsiveImg">
            <div className="flex justify-center absolute mt-2 responsiveImg cursor-pointer w-[95px] h-[95.5px] rounded-[50%] ml-7 bg-center bg-no-repeat bg-cover" style={image2 ? { backgroundImage: `url(${image2})` } : null}>
              <input
                onChange={(e) => handleChangeImage(e, setImage2)}
                style={image2 ? { backgroundImage: `url(${image2})` } : null}
                type="file"
                className={image2 ? "opacity-0 responsiveImg cursor-pointer w-[95px] h-[95.5px] rounded-[50%] mt-2 ml-7 bg-center bg-no-repeat bg-cover" : "opacity-0 bg-black cursor-pointer w-[95px] h-[95.5px] rounded-[50%] absolute mt-2 ml-7 bg-center bg-no-repeat"}
              />
            </div>

          </div>
          <div className="text-center mb-64 lg:text-3xl text-2xl mt-4 slab">Her Name Here!</div>
        </div>


      </div>


      {/* popup */}

      {showModal ? (
        <>
          <div
            className="justify-center items-center flex overflow-x-hidden overflow-y-auto fixed inset-0 z-50 outline-none focus:outline-none"
          >
            <div className="relative w-96 my-6 mx-auto max-w-3xl">
              <div className="border-0 rounded-lg shadow-lg relative flex flex-col w-full bg-white outline-none focus:outline-none">
                <div className="relative p-6 flex-auto">
                  <p className="my-4 text-slate-500 slab text-3xl leading-relaxed">
                    no face detected
                  </p>
                </div>
                <div className="flex items-center justify-end p-6 border-t border-solid border-slate-200 rounded-b">
                  <button
                    className="text-[#FF2C61] slab hover:bg-[#ED709D] hover:text-white font-bold uppercase px-6 py-3 rounded-xl text-2xl outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
                    type="button"
                    onClick={() => closeUploadImg()}
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div className="opacity-25 fixed inset-0 z-40 bg-black"></div>
        </>
      ) : null}

      {/* footer */}

      <div className="ocean">
        <div className="wave absolute"></div>
        <div className="wave2"></div>
      </div>

    </div >
  );
}

export default Home;