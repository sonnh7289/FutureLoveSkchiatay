import React from "react";
import Header from "../components/Header";
import EventHistory from "../components/eventHistory";
import Comments from "../components/comments";

function Historyv2() {
  return (
    <div className="Historyv2 flex flex-col min-h-screen" style={{
      background: 'linear-gradient(to right, #f7c1d6, #a9329a)'
    }}>
      <Header />
      <div className="flex-row justify-around overflow-hidden lg:flex ">
        <div className=" lg:w-[50%] lg:mx-28">
          <EventHistory />
        </div>
        <div>
        </div>
        <div className=" lg:w-[50%] lg:mx-4">
          <Comments />
        </div>
      </div>
    </div >

  );
}

export default Historyv2;
