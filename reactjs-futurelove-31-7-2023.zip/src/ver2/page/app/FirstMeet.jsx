import React, { useState, useEffect } from "react";
import axios from "axios";
import img1 from "../../components/image/finish.png"
import img4 from "./img/phaitren.png"
import img5 from "./img/phaiduoi.png"
import img6 from "./img/traitren.png"
import img7 from "./img/traiduoi.png"



function FirstMeet() {

    const [data, setData] = useState([])
    // const { id } = useParams();

    const fetchData = async () => {
        try {
            const response = await axios.get(
                `http://14.225.7.221:8989/lovehistory/272`
            )
            setData(response.data.sukien[0])
            console.log(response.data.sukien[0])
            // console.log(data)
        } catch (err) {
            console.log(err)
        }
    }
    useEffect(() => {
        fetchData();
    }, []);

    const img2 = "https://generation-sessions.s3.amazonaws.com/a6c87cf4275ca96f7141a113f2447e31/img/group-48096950-1@2x.png"
    const img3 = "https://generation-sessions.s3.amazonaws.com/a6c87cf4275ca96f7141a113f2447e31/img/group-48096951-1@2x.png"

    return (
        // <div
        //     className={` lg:w-[1019px] w-[380px] mb-12 border-8 border-pink-300  h-[573px] bg-white rounded-[36px] flex flex-row items-center justify-center mt-[75px] ml-[30px]`}
        // >
        //     <div className="-ml-2 bg-no-repeat bg-cover lg:w-[820px] lg:h-[282px] w-[500px] h-[282px]" >
        //         {/* image love */}
        //         <div className="flex flex-col texts my-16 ml-20">
        //             <span key={data.id} to={`/ array / ${data.id}`} className="text-5xl"  >Fisrt Meet</span>
        //             <p className="text-3xl font-[Montserrat] max-w-2xl pt-3 max-h-96 overflow-y-auto h-32 mt-2 overflowsss">
        //                 {data.noi_dung_su_kien}
        //             </p>
        //             <div className="flex flex-row ">
        //                 <div>
        //                     <img className="h-[28px] w-[35px] mt-[20px]"  src={img2} />
        //                     {data.count_comment}
        //                 </div>
        //                 <div>
        //                     <img className="h-[28px] w-[35px] mt-[20px] ml-[60px]" src={img3} />
        //                     {data.count_comment}
        //                 </div>
        //             </div>
        //             <div className="my-4">
        //                 <span style={{ fontStyle: "normal", marginTop: 100 }} className="text-time">{data.real_time}</span>
        //             </div>
        //         </div>
        //         {/* image swap */}
        //         < div
        //             style={{ backgroundImage: `url(${data.link_da_swap})` }}
        //             className=" lg:w-[300px] lg:h-[300px] w-[270px] h-[280px] rounded-full bg-center bg-no-repeat bg-cover 5 img-title"
        //         >
        //             <div style={{ backgroundImage: `url(${img1})` }} className="rounded-[32px] bg-no-repeat bg-cover w-[350px] h-[330px] absolutess" />
        //         </div>
        //         {/* first event */}
        //     </div>

        // </div>
        <div
            className={` lg:w-[1019px] w-[380px] mb-12 border-8 border-pink-300  h-[573px] bg-white rounded-[36px] flex flex-row items-center justify-center mt-[75px] ml-[30px]`}
        >
            <div className="-ml-2 bg-no-repeat bg-cover w-[65%] h-[100%]" >
                <div>
                    <img src={img4} alt="" className="ml-[10px] mt-[5px]" />
                </div>
                {/* image love */}
                <div className="flex flex-col ml-[150px]">
                    <span key={data.id} to={`/ array / ${data.id}`} className="text-7xl mt-[-100px] "  >Fisrt Meet</span>
                    <p className="text-3xl font-[Montserrat] max-w-lg pt-3 max-h-[42rem] overflow-y-auto h-32 mt-[50px] h-[150px]">
                        {data.noi_dung_su_kien}
                    </p>
                    <div className="flex flex-row ">
                        <div>
                            <img className="h-[28px] w-[35px] mt-[30px]" src={img2} />
                            {data.count_comment}
                        </div>
                        <div>
                            <img className="h-[28px] w-[35px] mt-[30px] ml-[100px]" src={img3} />
                            {data.count_view}
                        </div>
                    </div>
                    <div className="my-4 ">
                        <span style={{ fontStyle: "normal" }} className="text-time text-3xl ">{data.real_time}</span>
                    </div>
                </div>
                {/* image swap */}
                <div>
                    <img src={img5} alt="" className="mt-[-90px] ml-[10px]" />
                </div>
            </div>
            <div className="w-[65%] h-[100%]">
                <div>
                    <img src={img6} alt="" className=" ml-[310px]" />
                </div>
                <div className="mt-[-130px]">
                    < div
                        style={{ backgroundImage: `url(${data.link_da_swap})` }}
                        className=" lg:w-[450px] lg:h-[450px] w-[405px] h-[405px] rounded-full bg-center bg-no-repeat bg-cover 5  "
                    >
                        <div style={{ backgroundImage: `url(${img1})` }} className="rounded-[32px] bg-no-repeat bg-cover w-[495px] h-[465px] ml-[-35px]" />
                    </div>
                    {/* first event */}
                </div>
                <div>
                    <img src={img7} alt="" className="mt-[-150px] ml-[310px]" />
                </div>
            </div>

        </div>
    );
}

export default FirstMeet;