import React, { useState, useEffect } from "react";
import axios from "axios";
import bgr from "./img/nen3.jpg"



function BreakingUp() {

    const [data, setData] = useState([])
    // const { id } = useParams();

    const fetchData = async () => {
        try {
            const response = await axios.get(
                `http://14.225.7.221:8989/lovehistory/272`
            )
            setData(response.data.sukien[1])
            console.log(response.data.sukien[1])
            // console.log(data)
        } catch (err) {
            console.log(err)
        }
    }
    useEffect(() => {
        fetchData();
    }, []);

    const img2 = "https://generation-sessions.s3.amazonaws.com/a6c87cf4275ca96f7141a113f2447e31/img/group-48096950-1@2x.png"
    const img3 = "https://generation-sessions.s3.amazonaws.com/a6c87cf4275ca96f7141a113f2447e31/img/group-48096951-1@2x.png"

    return (
        <div
            style={{ backgroundImage: `url(${bgr})` }}
            className={` lg:w-[1019px] w-[380px] mb-12 border-8 border-pink-300  h-[573px] bg-white rounded-[36px] flex flex-row items-center justify-center mt-[75px] ml-[30px]`}
        >
            

        </div>
    );
}

export default BreakingUp;