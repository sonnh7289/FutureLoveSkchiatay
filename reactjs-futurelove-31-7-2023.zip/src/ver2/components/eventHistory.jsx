import React, { useEffect, useState } from "react";
import girl from "./image/girl.jpg";
import { AiFillHeart } from "react-icons/ai";
import ReactLoading from "react-loading";
import { format } from "date-fns";
import Historyv2 from "../../ver2/page/Historyv2";
import { createBrowserHistory } from 'history';
import '../css/Header.css'
import img1 from '../components/image/finish.png'
import img2 from '../components/image/12.png'
import axios from "axios";

// import image1 from "../components/image/khung-vien-dep-33-removebg-preview.png"
// import image2 from "../components/image/khung-vien-dep-powerpoint_022258315.png"


function EventHistory() {
  const [data, setData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [loadingType, setLoadingType] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const history = createBrowserHistory();


  const resultsPerPage = 8;


  // const images = [
  //   { url: image1, alt: 'Image 1' },
  //   { url: image2, alt: 'Image 2' },
  // ];

  // for (let i = 0; i < images.length; i++) {
  //   const image = images[i];
  //   // console.log(`Image URL: ${image.url}`);
  //   // console.log(`Image Alt: ${image.alt}`);
  // }


  const fetchData = async () => {
    try {
      const response = await fetch("http://14.225.7.221:8989/lovehistory/page/1");
      if (!response.ok) {
        throw new Error("Failed to fetch data");
      }
      const jsonData = await response.json();
      // const myJSON = (JSON.stringify(jsonData.list_sukien[0].sukien[0]));
      setData(jsonData.list_sukien[0].sukien);
      setIsLoading(false);
      console.log('abcd',jsonData.list_sukien[0].sukien);
    } catch (error) {
      console.log(error);
      setIsLoading(false);
    }
  };
  // const fetchData = async () => {
  //   try {
  //     const response = await axios.get(
  //       `http://14.225.7.221:8989/lovehistory/page/1`
  //     )
  //     if (!response) {
  //       throw new Error("Failed to fetch data");
  //     }
  //     setData(response.data.list_sukien[0].sukien);
  //     console.log('hhhhhhhhh', response.data.list_sukien[0].sukien)
  //     setIsLoading(false);
  //   } catch (error) {
  //     console.log(error);
  //     setIsLoading(false);
  //   }
  // };

  useEffect(() => {
    const loadingTypes = [
      "bars",
      "bubbles",
      "spinningBubbles",
      "spin",
      "cubes",
      "balls",
      "spokes",
      "cylon",
    ];

    const randomIndex = Math.floor(Math.random() * loadingTypes.length);
    const randomType = loadingTypes[randomIndex];
    setLoadingType(randomType);

    fetchData();
  }, []);

  const formatDateTime = (dateTime) => {
    return format(new Date(dateTime), "HH:mm:ss dd/MM/yyyy");
  };

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const handleEventHistory = () => {
    history.push({
      pathname: `/NewHistory`,

    });
    window.location.reload();
  };

  const sortedData = data.sort((a, b) => {
    const dateA = formatDateTime(a.real_time);
    const dateB = formatDateTime(b.real_time);
    return dateB - dateA;
  });

  const indexOfLastResult = currentPage * resultsPerPage;
  const indexOfFirstResult = indexOfLastResult - resultsPerPage;
  const currentResults = sortedData.slice(
    indexOfFirstResult,
    indexOfLastResult,
    // images
  );
  console.log('oki', currentResults);
  const totalPages = Math.ceil(sortedData.length / resultsPerPage);

  return (
    <div className=" flex justify-center items-center content-center font-sans EventHistory">
      {isLoading ? (
        <div className="flex justify-center items-center h-full">
          <div className="loader-container">
            <ReactLoading type={loadingType} color="#000000" />
            <p className="mt-4 text-gray-500 text-3xl">Loading...</p>
          </div>

        </div>
      ) : (
        <div className="">
          {currentResults.map((array, index) => (
            < div
              onClick={handleEventHistory}
              key={index}
              className={` lg:w-[680px] w-[380px] mb-12 border-8 border-pink-300  h-[300px] bg-white rounded-[36px] flex flex-row`}
            >
              <div style={{ backgroundImage: `url(${img2})` }} className="-ml-2 bg-no-repeat bg-cover lg:w-[820px] lg:h-[282px] w-[500px] h-[282px]" >
                {/* image love */}
                <div className="flex flex-col texts my-16 ml-20">
                  <span key={array.id} to={`/ array / ${array.id}`} className="text-3xl"  >{array.ten_su_kien}</span>
                  <p className="text-2xl font-[Montserrat] max-w-lg pt-3 max-h-96 overflow-y-auto h-32 mt-2 overflowsss">
                    {array.noi_dung_su_kien}
                  </p>
                  <div className="my-4">
                    <span style={{ fontStyle: "normal", marginTop: 100 }} className="text-time">{array.real_time}</span>
                  </div>
                </div>
                {/* image swap */}
                < div
                  style={{ backgroundImage: `url(${array.link_da_swap})` }}
                  className=" lg:w-[180px] lg:h-[200px] w-[150px] h-[100px] rounded-full bg-center bg-no-repeat bg-cover img-title"
                >
                  <div style={{ backgroundImage: `url(${img1})` }} className="rounded-[32px] bg-no-repeat bg-cover w-[100px] h-[100px] absolutess" />
                </div>
                {/* first event */}
              </div>
            </div>
          ))

          }
        </div>
      )
      }
    </div >
  );
}

export default EventHistory;