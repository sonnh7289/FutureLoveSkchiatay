import React, { useEffect, useState } from "react";
import girl from "./image/girl.jpg";
import useEventStore from "../../utils/store";
import axios from "axios";

function Comments() {
  const [data, setData] = useState([]);
  const setEvent = useEventStore((state) => state.setEvent);
  const [currentPage, setCurrentPage] = useState(1);
  const resultsPerPage = 10;

  const fetchData = async () => {
    try {
      const res = await axios.get(`http://14.225.7.221:8989/lovehistory/pageComment/1`);
      setData(res.data.comment);
      setEvent(res.data);
      console.log(res);
      const ipAddress = data.dia_chi_ip; // Lấy địa chỉ IP từ dữ liệu response
      console.log(`Địa chỉ IP của bạn là: ${ipAddress}`);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const dataSort = data.sort((a, b) => {
    const dateA = new Date(a.thoi_gian_release);
    const dateB = new Date(b.thoi_gian_release);

    return dateB - dateA;
  });

  const indexOfLastResult = currentPage * resultsPerPage;
  const indexOfFirstResult = indexOfLastResult - resultsPerPage;
  const currentResults = dataSort.slice(indexOfFirstResult, indexOfLastResult);
  const totalPages = Math.ceil(dataSort.length / resultsPerPage);

  return (
    <div className="lg:w-[450px] w-[350px] mx-8 h-fit bg-white rounded-[36px] text-center font-[Montserrat] flex justify-center items-center content-center">
      <ul className="p-8">
        {currentResults.map((data, i) => (
          <li className="flex flex-row w-full h-32 justify-between" key={i}>
            {data.imageattach === null && data.imageattach === undefined && (
              <img src={data.avatar_user} alt="" className="w-20 h-20 rounded-[50%] mr-5" />
            )}

            <span className="text-[16px]"> {data.device_cmt}</span>
            <span className="text-[16px] max-w-xl">
              {data.noi_dung_cmt.length > 15
                ? data.noi_dung_cmt.slice(0, 50) + "..."
                : data.noi_dung_cmt}
            </span>
            <span className="text-[16px]">
              {data.dia_chi_ip.length > 15
                ? data.dia_chi_ip.slice(0, 15) + "..."
                : data.dia_chi_ip}
            </span>
          </li>
        ))}

        {/* {[...Array(25)].map((_, index) => (
          <li className="flex flex-row w-full h-32 justify-between" key={index}>
            <img src={girl} alt="" className="w-20 h-20 rounded-[50%]" />
            <span className="text-[16px] max-w-xl">
              Love makes every moment brighter, warmer, and infinitel...
            </span>
            <span className="text-[16px]">1m</span>
          </li>
        ))} */}
      </ul>
    </div>
  );
}

export default Comments;